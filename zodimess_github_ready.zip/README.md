
# ZodiMess – Southern Hemisphere Zodiac 💫

Welcome to **ZodiMess**, the chaotic and cosmic horoscope experience for the Southern Hemisphere. This project is optimized for GitHub Pages deployment with a flat file structure.

---

## 🚀 How to Deploy on GitHub Pages

1. **Unzip `zodimess_final_site.zip`**
   - You should have:
     - `index.html`
     - `compatibility_index.html`
     - `logo.png`

2. **Create a new GitHub repo** (or use your existing one)

3. **Upload the unzipped files to the root** of your repository:
   ```
   your-repo/
   ├── index.html
   ├── compatibility_index.html
   └── logo.png
   ```

4. **Commit your changes** to `main` branch

5. **Enable GitHub Pages**:
   - Go to **Settings** → **Pages**
   - Select:
     - Source: `Deploy from a branch`
     - Branch: `main`
     - Folder: `/ (root)`
   - Save

6. **Your site will be available at**:
   ```
   https://yourusername.github.io/your-repo-name
   ```

---

## 📎 Notes

- The **Compatibility Grid** is available at:  
  [yourdomain]/compatibility_index.html

- The structure is flat to support GitHub Pages routing.

---

## 💌 Credits

Built with love, sass, and questionable astrological accuracy by you & Nova.
